
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-header">Show Employee</div>
  <div class="card-body">
      <div class="row">
        <div class="col-3"></div>
        <div class="col-6">

 <form action="" method="post">
  <div class="row">
       <div class="col-6">
         <div class="form-group">
            <label>First Name</label>
            <input type="text" value="<?php echo e($employees->firstname); ?>" class="form-control" readonly>
        </div>
      </div>
      <div class="col-6">
        <div class="form-group">
            <label>Last Name</label>
            <input type="text" value="<?php echo e($employees->lastname); ?>" class="form-control" readonly>
     </div>
  </div>
  </div>
  <div class="row">
       <div class="col-6">

     <div class="form-group">
       <label>Gender</label>
        <input type="text" value="<?php echo e($employees->gender); ?>" class="form-control" readonly>
     </div>
     </div>
      <div class="col-6">
     <div class="form-group">
        <label>Age</label>
        <input type="text" value="<?php echo e($employees->age); ?>" class="form-control" readonly>
     </div>
     </div>
  </div>
  <div class="row">
       <div class="col-6">
     <div class="form-group">
        <label>Email Address</label>
        <input type="email" value="<?php echo e($employees->email); ?>" class="form-control" readonly>
     </div>
     </div>
      <div class="col-6">
     <div class="form-group">
        <label>Mobile Number</label>
        <input type="text" value="<?php echo e($employees->mobile_number); ?>" class="form-control" readonly>
     </div>
     </div>
  </div>
     <div class="form-group">
        <label>Complete Address</label>
        <input type="text" value="<?php echo e($employees->complete_address); ?>" class="form-control" readonly>
     </div>

     <div class="row">
       <div class="col-6">
     <div class="form-group">
        <label>Position</label>
        <input type="text" value="<?php echo e($employees->position); ?>" class="form-control" readonly>
     </div>
     </div>
      <div class="col-6">
     <div class="form-group">
        <label>Date Hire</label>
        <input type="text" value="<?php echo e($employees->date_hire); ?>" class="form-control" readonly>
     </div>
     </div>
  </div>

    </form>
    </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('employees.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel10\resources\views/employees/show.blade.php ENDPATH**/ ?>