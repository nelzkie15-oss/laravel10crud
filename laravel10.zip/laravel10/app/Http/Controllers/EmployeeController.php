<?php

namespace App\Http\Controllers;
 
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\Employee;
use Illuminate\View\View;

class EmployeeController extends Controller
{
 
    public function index(): View
    {
        $employees = Employee::all();
        return view ('employees.index')->with('employees', $employees);
    }

    public function create(): View
    {
        return view('employees.create');
    }

    public function store(Request $request): RedirectResponse
    {

        $request->validate([
            'firstname' => 'required',
            'lastname' => 'required',
            'gender' => 'required',
            'age' => 'required',
            'email' => 'required',
            'mobile_number' => 'required',
            'complete_address' => 'required',
            'position' => 'required',
            'date_hire' => 'required'
        ]);
  
        Employee::create($request->all());
        // $input = $request->all();
        // Employee::create($input);
        return redirect('employee')->with('flash_message', 'Employee Addedd!');
    }

    public function show(string $id): View
    {
        $employee = Employee::find($id);
        return view('employees.show')->with('employees', $employee);
    }


    public function edit(string $id): View
    {
        $employee = Employee::find($id);
        return view('employees.edit')->with('employees', $employee);
    }

    public function update(Request $request, string $id): RedirectResponse
    {
        $employee = Employee::find($id);
        $input = $request->all();
        $employee->update($input);
        return redirect('employee')->with('flash_message', 'Employee Updated!');  
    }
 
    public function destroy(string $id): RedirectResponse
    {
        Employee::destroy($id);
        return redirect('employee')->with('flash_message', 'Employee deleted!');
    }
}
