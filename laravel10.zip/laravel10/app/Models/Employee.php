<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    protected $table = 'employees';
    protected $primaryKey = 'id';
    protected $fillable = ['firstname', 'lastname', 'gender', 'age', 'email', 'mobile_number', 'complete_address', 'position', 'date_hire'];
    use HasFactory;
}
