@extends('employees.layout')
@section('content')
<div class="card">
  <div class="card-header">Add Employee</div>
  <div class="card-body">
      <div class="row">
        <div class="col-3"></div>
        <div class="col-6">
        <!-- @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Error!</strong> <br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif -->
      <form action="{{ url('employee') }}" method="post">
        {!! csrf_field() !!}
  <div class="row">
       <div class="col-6">
         <div class="form-group">
            <label>First Name</label>
            <input type="text" name="firstname" id="firstname" class="form-control mb-1 @error('firstname') is-invalid @enderror">
            @error('firstname')
             <span class="badge rounded-pill text-bg-danger">{{ $message }}</span>
            @enderror
        </div>
      </div>
      <div class="col-6">
        <div class="form-group">
            <label>Last Name</label>
            <input type="text" name="lastname" id="lastname" class="form-control mb-1 @error('lastname') is-invalid @enderror">
            @error('lastname')
             <span class="badge rounded-pill text-bg-danger">{{ $message }}</span>
            @enderror
     </div>
  </div>
  </div>
  <div class="row">
       <div class="col-6">

     <div class="form-group">
       <label>Gender</label>
        <input type="text" name="gender" id="gender" class="form-control mb-1 @error('gender') is-invalid @enderror">
        @error('gender')
             <span class="badge rounded-pill text-bg-danger">{{ $message }}</span>
            @enderror
     </div>
     </div>
      <div class="col-6">
     <div class="form-group">
        <label>Age</label>
        <input type="text" name="age" id="age" class="form-control mb-1 @error('age') is-invalid @enderror">
        @error('age')
             <span class="badge rounded-pill text-bg-danger">{{ $message }}</span>
            @enderror
     </div>
     </div>
  </div>
  <div class="row">
       <div class="col-6">
     <div class="form-group">
        <label>Email Address</label>
        <input type="email" name="email" id="email" class="form-control mb-1 @error('email') is-invalid @enderror">
        @error('email')
             <span class="badge rounded-pill text-bg-danger">{{ $message }}</span>
            @enderror
     </div>
     </div>
      <div class="col-6">
     <div class="form-group">
        <label>Mobile Number</label>
        <input type="text" name="mobile_number" minlength="10" maxlength="11"  id="mobile_number" class="form-control mb-1 @error('mobile_number') is-invalid @enderror">
        @error('mobile_number')
             <span class="badge rounded-pill text-bg-danger">{{ $message }}</span>
            @enderror
     </div>
     </div>
  </div>
     <div class="form-group">
        <label>Complete Address</label>
        <input type="text" name="complete_address" id="complete_address" class="form-control mb-1 @error('complete_address') is-invalid @enderror">
        @error('complete_address')
             <span class="badge rounded-pill text-bg-danger">{{ $message }}</span>
            @enderror
     </div>

     <div class="row">
       <div class="col-6">
     <div class="form-group">
        <label>Position</label>
        <input type="text" name="position" id="position" class="form-control mb-1 @error('position') is-invalid @enderror">
        @error('position')
             <span class="badge rounded-pill text-bg-danger">{{ $message }}</span>
            @enderror
     </div>
     </div>
      <div class="col-6">
     <div class="form-group">
        <label>Date Hire</label>
        <input type="date" name="date_hire" id="date_hire" class="form-control mb-1 @error('date_hire') is-invalid @enderror">
        @error('date_hire')
             <span class="badge rounded-pill text-bg-danger">{{ $message }}</span>
            @enderror
     </div>
     </div>
  </div>
     <div class="form-group mt-2">
        <input type="submit" value="Submit" class="btn btn-success" style="float:right">
    </div>
    </form>
    </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
@stop