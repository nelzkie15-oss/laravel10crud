<!DOCTYPE html>
<html>
<head>
    <title>Employee Application laravel 10</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

   <link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css"/>
   <script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.3.min.js"></script>
   <script src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>

   <script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
    $('#mytable').dataTable();
    } );
    </script> 
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary mb-4" style="background-color:#eb4432!important;color:#fff">
  <div class="container-fluid">
    <a class="navbar-brand" href="{{ url('/employee') }}" style="color:#fff">Laravel 10</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item" >
          <a class="nav-link active" aria-current="page" href="{{ url('/employee') }}" style="color:#fff">Home</a>
        </li>

 
      </ul>
    
    </div>
  </div>
</nav>
<div class="container">
    @yield('content')
</div>
  
</body>
</html>