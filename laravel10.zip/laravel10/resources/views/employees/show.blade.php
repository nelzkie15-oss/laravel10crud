@extends('employees.layout')
@section('content')
<div class="card">
  <div class="card-header">Show Employee</div>
  <div class="card-body">
      <div class="row">
        <div class="col-3"></div>
        <div class="col-6">

 <form action="" method="post">
  <div class="row">
       <div class="col-6">
         <div class="form-group">
            <label>First Name</label>
            <input type="text" value="{{ $employees->firstname }}" class="form-control" readonly>
        </div>
      </div>
      <div class="col-6">
        <div class="form-group">
            <label>Last Name</label>
            <input type="text" value="{{ $employees->lastname }}" class="form-control" readonly>
     </div>
  </div>
  </div>
  <div class="row">
       <div class="col-6">

     <div class="form-group">
       <label>Gender</label>
        <input type="text" value="{{ $employees->gender }}" class="form-control" readonly>
     </div>
     </div>
      <div class="col-6">
     <div class="form-group">
        <label>Age</label>
        <input type="text" value="{{ $employees->age }}" class="form-control" readonly>
     </div>
     </div>
  </div>
  <div class="row">
       <div class="col-6">
     <div class="form-group">
        <label>Email Address</label>
        <input type="email" value="{{ $employees->email }}" class="form-control" readonly>
     </div>
     </div>
      <div class="col-6">
     <div class="form-group">
        <label>Mobile Number</label>
        <input type="text" value="{{ $employees->mobile_number }}" class="form-control" readonly>
     </div>
     </div>
  </div>
     <div class="form-group">
        <label>Complete Address</label>
        <input type="text" value="{{ $employees->complete_address }}" class="form-control" readonly>
     </div>

     <div class="row">
       <div class="col-6">
     <div class="form-group">
        <label>Position</label>
        <input type="text" value="{{ $employees->position }}" class="form-control" readonly>
     </div>
     </div>
      <div class="col-6">
     <div class="form-group">
        <label>Date Hire</label>
        <input type="text" value="{{ $employees->date_hire }}" class="form-control" readonly>
     </div>
     </div>
  </div>

    </form>
    </div>
    </div>
  </div>
</div>
@stop